#!/usr/bin/env python
# vim: fileencoding=utf-8

"""
Copyright (C) 2011 Tatt61880 (tatt61880@gmail.com, @tatt61880)
Last Change: 2011/02/13 20:36:02.

"""

from optparse import OptionParser, OptionValueError
import sys
import unittest
import phn_output
from xml.etree.ElementTree import fromstring
from math import *

parser = OptionParser()
parser.add_option(
    "-d", "--debug",
     action="store_true", # Trueを保存
                          # store_falseならFalseを保存
     default=False,
     help="debug"
)
(options, args) = parser.parse_args()

# ============================================
def create_elements(e):#{{{
    ret = ""
    if isinstance(e, tuple):
        ret += "<g "
        for key, value in e[0].iteritems():
            ret += ''' %s="%s"''' % (key, value)
        ret += "> "
        ret += create_elements(e[1])
        ret += "</g>"
    else:
        ret += "<%s " % e.pop('tag')
        for key, value in e.iteritems():
            ret += ''' %s="%s"''' % (key, value)
        ret += " />"
    return ret
#}}}
def parse_elements(elements):#{{{
    elements_data = create_elements(elements)

    svg_data = fromstring("""
<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="90"
   height="90"
   id="svg2"
   version="1.1"
   inkscape:version="0.48.0 r9654"
   sodipodi:docname="a.svg">""" + elements_data + "</svg>")
    phunData=[]
    phn_output.parse_svg(svg_data, phn_output.Matrix([1,0,0,1,0,0]), phn_output.SVG_Style({'fill':'black', 'fill-opacity':'1', 'stroke':'none', 'stroke-opacity':'1', 'opacity':'1'}), phunData)
    return phunData
#}}}

# ============================================
# Classes
# ============================================
class _SVG_element(dict):#{{{
    default_attributes = None
    def parse(self):
        return parse_elements(self)[0]
    def __init__(self, **keywords):
        self.update(self.default_attributes)
        self.update(**keywords)
#}}}
class Path(_SVG_element):#{{{
    default_attributes = dict(tag='path', d='M 0,0 1,0 0,1z')
#}}}
class Rect(_SVG_element):#{{{
    default_attributes = dict(tag='rect', width=1, height=1)
#}}}
class Circle(_SVG_element):#{{{
    default_attributes = dict(tag='circle', r=1)
#}}}
class PathCircleRadius1m(_SVG_element):#{{{  #FIXME Inkscapeからの依存をなくす
    default_attributes = {
            'tag':'path',
            'sodipodi:cx':0, 'sodipodi:cy':0, 'sodipodi:rx':1, 'sodipodi:ry':1, 'sodipodi:type':'arc',
            'd':'m -1,-1 a 1,1 0 0 0 1,0 1,1 0 0 0 -1,0 z'
            }
#}}}
class Ellipse(_SVG_element):#{{{
    default_attributes = dict(tag='ellipse', cx=0, cy=0)
#}}}

class Line(_SVG_element):#{{{
    default_attributes = dict(tag='line', x1=0, y1=0, x2=0, y2=0)
#}}}
class Polyline(_SVG_element):#{{{
    default_attributes = dict(tag='polyline')
#}}}
class Polygon(_SVG_element):#{{{
    default_attributes = dict(tag='polygon')
#}}}

# ============================================
# Tests
# ============================================
class testPath(unittest.TestCase):#{{{
    pass #TODO Pathが真円状の場合に, sodipodi:rxのような表記がなくても、Polygonでなく、Circleに変換できるように。
#    def test_path_perfect_circle(self):
#        p = Path(d="m -201.59999,10.8 a 28.799999,28.799999 0 1 1 -57.6,0 28.799999,28.799999 0 1 1 57.6,0 z").parse()
#        self.assertTrue(isinstance(p, phn_output.Circle))

    def test_path_pos(self):
        p = Path(d="M0 0 10 0 10 10 0 10").parse()
        self.assertAlmostEquals(p['pos'], phn_output.Vector([5, 5]))

    def test_path_area(self):
        p = Path(d="M0 0 10 0 10 10 0 10").parse()
        self.assertAlmostEquals(p._area, 100)

    def test_path_pos_triangle(self):
        p = Path(d="M0 0 10 0 5 6").parse()
        self.assertAlmostEquals(p['pos'], phn_output.Vector([5, 2]))

    def test_path_pos_hollow(self):
        p = Path(d="M0 0 10 0 10 10 0 10zM1 1 6,1 6,6 1 6z").parse()
        self.assertAlmostEquals(p['pos'], phn_output.Vector([5.5, 5.5]))

    def test_path_pos_hollow2(self):
        p = Path(d="M0 0 10 0 10 10 0 10zM1 1 1,6 6,6 6 1z").parse()
        self.assertAlmostEquals(p['pos'], phn_output.Vector([5.5, 5.5]))

    def test_path_pos_hollow_noncommand_followingZ(self):
        p = Path(d="M0 0 10 0 10 10 0 10z1 1 6,1 6,6 1 6z").parse()

#}}}
class testRect(unittest.TestCase):#{{{
    def test_rect(self):
        p = Rect(width=100,height=30).parse()
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], tuple([100, 30]))

    def test_rect_rotate90deg(self):
        p = Rect(transform="rotate(90)").parse()
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["angle"], pi/2)

    def test_rect_rotate30deg(self):
        p = Rect(transform="rotate(30)").parse()
        self.assertAlmostEquals(p['angle'], pi/6)

    def test_rect_rotate0deg(self):
        p = Rect(transform="rotate(0)").parse()
        self.assertEquals(p["angle"], 0)

    def test_rect_rotate3args(self):
        p = Rect(transform="rotate(30 100 200)").parse()
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertAlmostEquals(p['angle'], pi/6)

    def test_rect_double_transform(self):
        p = Rect(transform="rotate(0) rotate(60)").parse()
        self.assertAlmostEquals(p["angle"], pi/3)

    def test_rect_double_transform2(self):
        p = Rect(width=100, height=200, transform="rotate(30) scale(10, 3)").parse()
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertAlmostEquals(p['angle'], pi/6)
        self.assertEquals(p["size"], (1000,600))

    def test_rect_matrix(self):
        p = Rect(width=100, height=200, transform="matrix(2,0,0,1,0,0)").parse()
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["angle"], 0)
        self.assertEquals(p["size"], (200,200))

    def test_rect_sclae(self):
        p = Rect(width=100, height=200, transform="scale(2, -1)").parse()
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], (200,200))

    def test_rect_void_transform(self):
        p = Rect().parse()
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["angle"], 0)

    def test_rect_transform2polygon(self):
        p = Rect(transform="scale(10, 2) rotate(30)").parse()
        self.assertTrue(isinstance(p, phn_output.Polygon))

    def test_rect_ry(self):
        p = Rect(ry="0.1").parse()
        self.assertTrue(isinstance(p, phn_output.Polygon))

    def test_rect_ry_rx0(self):
        p = Rect(ry="0.1", rx="0").parse()
        self.assertTrue(isinstance(p, phn_output.Box))
#}}}
class testCircle(unittest.TestCase): #{{{
    def test_circle(self):
        p = Circle(r=1).parse()
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Circle))
        self.assertEquals(p["radius"], 1)

    def test_circle_scale(self):
        p = Circle(r=1, transform="scale(2,1)").parse()
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Polygon))

    def test_circle_filtered(self):
        '''Filtered circle should be converted into tracer'''
        p = Circle(r=1, style="filter:hoge").parse()
        self.assertTrue(isinstance(p, phn_output._PhunAttachment))
        self.assertTrue(isinstance(p, phn_output.Pen))

#}}}
class testInkscapeEllipse(unittest.TestCase):#{{{
    def test_inkscape_ellipse_normal_ellipse(self):
        p = PathCircleRadius1m().parse()
        self.assertTrue(isinstance(p, phn_output.Circle))

    def test_inkscape_ellipse_rotated_ellipse(self):
        p = PathCircleRadius1m(transform="rotate(30)").parse()
        self.assertTrue('angle' in p)
        self.assertTrue(isinstance(p, phn_output.Circle))
        self.assertAlmostEquals(p['angle'], pi/6)
        self.assertEquals(p['radius'], 1)

    def test_inkscape_ellipse_scaled_ellipse(self):
        p = PathCircleRadius1m(transform="scale(1,2)").parse()
        self.assertTrue(isinstance(p, phn_output.Polygon))

    def test_inkscape_ellipse_half_ellipse(self):
        p = PathCircleRadius1m(**{"sodipodi:end":"1"}).parse()
        self.assertTrue(isinstance(p, phn_output.Polygon))
#}}}
class testEllipse(unittest.TestCase): #{{{
    def test_ellipse(self):
        p = Ellipse(rx=2, ry=1).parse()
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Polygon))

    def test_ellipse_rx_equal_ry(self):
        p = Ellipse(rx=2, ry=2).parse()
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Circle))
        self.assertTrue(p['radius'], 2)

    def test_ellipse_rx_equal_ry_scaled(self):
        p = Ellipse(rx=2, ry=2, transform="scale(1,2)").parse()
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Polygon))




#}}}

class testGroup(unittest.TestCase):#{{{
    def test_group_rotates(self):
        elements = ({"transform":"rotate(30)"}, 
                        Rect(**{"transform":"rotate(60)"}))
        p = parse_elements(elements)
        self.assertAlmostEquals(p[0]['angle'], pi/2)
        self.assertTrue(isinstance(p[0], phn_output.Box))

    def test_group_scales(self):
        elements = ({"transform":"scale(1,-3)"},
                        Rect(**{"width":100, "height":100, "transform":"scale(10,2)"}))
        p = parse_elements(elements)
        self.assertEquals(p[0]['size'], phn_output.Vector([1000, 600]))

    def test_group_scales_triple(self):
        elements = ({"transform":"scale(0.5,-3)"},
                        ({"transform":"scale(1,-3)"},
                            Rect(**{"width":100, "height":100, "transform":"scale(10,2)"})))
        p = parse_elements(elements)[0]
        self.assertEquals(p['size'], phn_output.Vector([500, 1800]))

    def test_group_opacity(self):
        elements = ({"style":"opacity:0.2"},
                        ({"opacity":"0.3"},
                            Rect(**{"style":"fill-opacity:0.7;fill:#00FFFF"})))
        p = parse_elements(elements)[0]
        self.assertAlmostEquals(p['color'][3], 0.042)

    def test_group_inherited_color(self):
        elements = ({"style":"fill:red"},
                        Rect(**{"style":""}))
        p = parse_elements(elements)[0]
        self.assertEquals(p['color'], phn_output.Color([1,0,0,1]))


#}}}
# ============================================
class testStyle(unittest.TestCase): #{{{
    def test_style_fill_red(self):
        p = Rect(style='fill:#FF0000').parse()
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))

    def test_style_fill_red2(self):
        p = Rect(style='fill:#F00').parse()
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))

    def test_style_fill_red3(self):
        p = Rect(style='fill:rgb(100%,0,0)').parse()
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))

    def test_style_fill_red4(self):
        p = Rect(style='fill:rgb(255,0,0)').parse()
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))

    def test_style_fill_010101(self):
        p = Rect(style="fill:#0180B9").parse()
        self.assertEquals(p["color"], phn_output.Color([1/255., 0x80/255., 1.0*0xB9/0xFF, 1.0]))

    def test_style_fill_lowercase(self):
        p = Rect(style="fill:#ff00ff").parse()
        self.assertEquals(p["color"], phn_output.Color([1, 0, 1, 1]))

    def test_style_notGiven(self):
        p = Rect(style="").parse()
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_none(self):
        p = Rect(style="fill:none").parse()
        self.assertEquals(p["color"][3], 0)

    def test_style_fill_none_strokeFF00FF(self):
        p = Rect(style="fill:none;stroke:#FF00FF").parse()
        self.assertEquals(p["color"], phn_output.Color([1, 0, 1, 0]))

    def test_style_invalid(self):
        p = Rect(style="a").parse()
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_invalid2(self):
        p = Rect(style="a; fill:#00FF00").parse()
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_invalid3(self):
        p = Rect(style="fill:blackk").parse()
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_invalid4(self):
        p = Rect(style="fill:rgb(1,2,3,4)").parse()
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_fill_opacity(self):
        p = Rect(style="fill:#FF0000; opacity:0.5").parse()
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 0.5]))

    def test_style_fill_string(self):
        p = Rect(style="fill:blue;").parse()
        self.assertEquals(p["color"], phn_output.Color([0, 0, 1, 1]))

    def test_style_fill_none_stroke_none(self):
        p = Rect(style="fill:none; stroke:none").parse()
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 0]))
#}}}
# ============================================
class testMatrix(unittest.TestCase): #{{{
    def test_matrix(self):
        p = Rect(width=100, height=200, transform="scale(2, -1)").parse()
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], (200,200))

    def test_matrix_invalid(self):
        p = Rect(width=100, height=200, transform="scale(2, -1").parse()
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], (100,200))

    def test_matrix_invalid2(self):
        p = Rect(width=100, height=200, transform="scale(2, -1, 3)").parse()
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], (100,200))
#}}}
class testVector(unittest.TestCase):#{{{
    def test_vector_add(self):
        a = phn_output.Vector([1,2])
        b = phn_output.Vector([3,4])
        self.assertEquals(a+b, phn_output.Vector([4, 6]))

    def test_vector_pos(self):
        a = phn_output.Vector([1,2])
        self.assertEquals(+a, phn_output.Vector([1, 2]))

    def test_vector_neg(self):
        a = phn_output.Vector([1,2])
        self.assertEquals(-a, phn_output.Vector([-1, -2]))

    def test_vector_norm(self):
        a = phn_output.Vector([3,4])
        self.assertEquals(abs(a), 5)
#}}}
# ============================================
class testTemp(unittest.TestCase): #{{{
#    def test_style_fill_red(self):
#        p = Rect(style='fill:#FF0000').parse()
#        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))
    def test_path_pos_hollow2(self):
        p = Path(d="M0 0 10 0 10 10 0 10zM1 1 1,6 6,6 6 1z").parse()
        self.assertAlmostEquals(p['pos'], phn_output.Vector([5.5, 5.5]))

#}}}

##############################################
def suite(): #{{{
    suite = unittest.TestSuite()

    DEBUG = options.debug
    if DEBUG:
        suite.addTest(unittest.makeSuite(testTemp))
    else:
        suite.addTest(unittest.makeSuite(testPath))
        suite.addTest(unittest.makeSuite(testRect))
        suite.addTest(unittest.makeSuite(testCircle))
        suite.addTest(unittest.makeSuite(testInkscapeEllipse))
        suite.addTest(unittest.makeSuite(testEllipse))

        suite.addTest(unittest.makeSuite(testGroup))

        suite.addTest(unittest.makeSuite(testStyle))

        suite.addTest(unittest.makeSuite(testMatrix))
        suite.addTest(unittest.makeSuite(testVector))

    return suite
#}}}

if __name__ == '__main__':
    unittest.TextTestRunner(verbosity=1).run(suite())

# vim: expandtab shiftwidth=4 tabstop=8 softtabstop=4 fileencoding=utf-8 textwidth=99
