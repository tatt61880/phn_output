#!/usr/bin/env python
# coding: utf-8

"""
Copyright (C) 2011 Tatt61880 (tatt61880@gmail.com, @tatt61880)
Last Change: 2011/02/09 00:09:07.
"""

import sys, re
import zipfile
import time

now = time.localtime(time.time())[:5]
time_stamp = "".join(["_%02d" % x for x in now])

#now = time.localtime(time.time())
#time_stamp = "%4d_%02d%02d_%02d%02d" % (now.tm_year, now.tm_month, now.tm_day, now.tm_hour, now.tm_minute)

version = ""

try:
    f = open("phn_output.py", "r")
    for line in f:
        m = re.search(r"VERSION = '(.*)'", line)
        if m:
            version = m.group(1)
finally:
    f.close()

# output file
zip_filename = "phn_output_v" + version + time_stamp + ".zip"

zip = zipfile.ZipFile('./'+zip_filename, 'w', zipfile.ZIP_DEFLATED)

# files
zip.write('./MAKEFILE')
zip.write('./phn_output.py')
zip.write('./phn_output.test.py')
zip.write('./phn_output.inx')
zip.write('./README.txt')
zip.write('./example.phn')
zip.write('./example.svg')
zip.write('./'+sys.argv[0])

zip.close()

# vim: expandtab shiftwidth=4 tabstop=8 softtabstop=4 encoding=utf-8 textwidth=99
