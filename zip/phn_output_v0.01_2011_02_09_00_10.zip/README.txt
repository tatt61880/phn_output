Phn output (Phun/Algodooユーザー用 Inkscape拡張)

Copyright (C) 2011 Tatt61880 (tatt61880@gmail.com, @tatt61880)
Last Change: 2011/02/08 23:52:25.

図形のみに対応しています。
複合パス、自己交差しているパスに未対応です。

http://dl.dropbox.com/u/9975638/Algodoo/Inkscape/phn_output/index.html

== 更新履歴 ==

