#!/usr/bin/env python
# coding: utf-8

"""
Copyright (C) 2011 Tatt61880 (tatt61880@gmail.com, @tatt61880)
Last Change: 2011/02/09 00:09:04.

"""

import unittest
import phn_output
from xml.etree.ElementTree import fromstring
from math import *

def _parse_path(**keywords):
    attributes = dict(d='M 0,0 1,0 0,1z')
    attributes.update(**keywords)
    return attributes.copy()

def _parse_inkscape_ellipse(**keywords):
    attributes = dict(cx=0, cy=0, rx=1, ry=1, type='arc', d='m -0.5,-0.5 a 0.5,0.5 0 0 0 0.5,0 0.5,0.5 0 0 0 -0.5,0 z')
    attributes.update(**keywords)
    for key in ('cx', 'cy', 'rx', 'ry', 'type'):
        attributes['sodipodi:'+key]=attributes[key]
        del attributes[key]
    return attributes.copy()

def _parse_rect(**keywords):
    attributes = dict(x=0, y=0, width=1, height=1)
    attributes.update(**keywords)
    return attributes.copy()

def parse_inkscape_ellipse(**keywords):
    return parse_elements(('path', _parse_inkscape_ellipse(**keywords)))[0]
def parse_path(**keywords):
    return parse_elements(('path', _parse_path(**keywords)))[0]
def parse_rect(**keywords):
    return parse_elements(('rect', _parse_rect(**keywords)))[0]

def create_elements(e):
    ret = ""
    if e[0] == 'g':
        ret += "<g "
        for key in e[1].keys():
            ret += ''' %s="%s"''' % (key, e[1][key])
        ret += "> "
        ret += create_elements(e[2])
        ret += "</g>"
    else:
        if e[0] == 'path':
            e[1].update(_parse_rect(**e[1]))
        if e[0] == 'rect':
            e[1].update(_parse_rect(**e[1]))

        ret += "<%s " % e[0]
        for key in e[1].keys():
            ret += ''' %s="%s"''' % (key, e[1][key])
        ret += " />"
    return ret

def parse_elements(elements):
    elements_data = create_elements(elements)

    e = fromstring("""
<svg
   xmlns:dc="http://purl.org/dc/elements/1.1/"
   xmlns:cc="http://creativecommons.org/ns#"
   xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
   xmlns:svg="http://www.w3.org/2000/svg"
   xmlns="http://www.w3.org/2000/svg"
   xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
   xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
   width="90"
   height="90"
   id="svg2"
   version="1.1"
   inkscape:version="0.48.0 r9654"
   sodipodi:docname="a.svg">""" + elements_data + "</svg>")
    phunData=[]
    phn_output.parse_svg(e, (1,0,0,1,0,0), None, phunData)
    return phunData

# ============================================

class testStyle(unittest.TestCase):
    def test_style_fill_red(self):
        p = parse_rect(style='fill:#FF0000')
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))

    def test_style_fill_red2(self):
        p = parse_rect(style='fill:#F00')
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))

    def test_style_fill_red3(self):
        p = parse_rect(style='fill:rgb(100%,0,0)')
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))

    def test_style_fill_red4(self):
        p = parse_rect(style='fill:rgb(255,0,0)')
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))

    def test_style_fill_010101(self):
        p = parse_rect(style="fill:#0180B9")
        self.assertEquals(p["color"], phn_output.Color([1/255., 0x80/255., 1.0*0xB9/0xFF, 1.0]))

    def test_style_fill_lowercase(self):
        p = parse_rect(style="fill:#ff00ff")
        self.assertEquals(p["color"], phn_output.Color([1, 0, 1, 1]))

    def test_style_notGiven(self):
        p = parse_rect(style="")
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_none(self):
        p = parse_rect(style="fill:none")
        self.assertEquals(p["color"][3], 0)

    def test_style_fill_none_strokeFF00FF(self):
        p = parse_rect(style="fill:none;stroke:#FF00FF")
        self.assertEquals(p["color"], phn_output.Color([1, 0, 1, 0]))

    def test_style_invalid(self):
        p = parse_rect(style="a")
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_invalid2(self):
        p = parse_rect(style="a; fill:#00FF00")
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_invalid3(self):
        p = parse_rect(style="fill:blackk")
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_invalid4(self):
        p = parse_rect(style="fill:rgb(1,2,3,4)")
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 1]))

    def test_style_fill_opacity(self):
        p = parse_rect(style="fill:#FF0000; opacity:0.5")
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 0.5]))

    def test_style_fill_string(self):
        p = parse_rect(style="fill:blue;")
        self.assertEquals(p["color"], phn_output.Color([0, 0, 1, 1]))

    def test_style_fill_none_stroke_none(self):
        p = parse_rect(style="fill:none; stroke:none")
        self.assertEquals(p["color"], phn_output.Color([0, 0, 0, 0]))

class testRect(unittest.TestCase):
    def test_rect(self):
        p = parse_rect(width=100,height=30)
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], tuple([100, 30]))

    def test_rect_rotate90deg(self):
        p = parse_rect(transform="rotate(90)")
        self.assertTrue(isinstance(p, phn_output._PhunGeometry))
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["angle"], pi/2)

    def test_rect_rotate30deg(self):
        p = parse_rect(transform="rotate(30)")
        self.assertAlmostEquals(p['angle'], pi/6)

    def test_rect_rotate0deg(self):
        p = parse_rect(transform="rotate(0)")
        self.assertEquals(p["angle"], 0)

    def test_rect_rotate3args(self):
        p = parse_rect(transform="rotate(30 100 200)")
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertAlmostEquals(p['angle'], pi/6)

    def test_rect_double_transform(self):
        p = parse_rect(transform="rotate(0) rotate(60)")
        self.assertAlmostEquals(p["angle"], pi/3)

    def test_rect_double_transform2(self):
        p = parse_rect(width=100, height=200, transform="rotate(30) scale(10, 3)")
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertAlmostEquals(p['angle'], pi/6)
        self.assertEquals(p["size"], (1000,600))

    def test_rect_matrix(self):
        p = parse_rect(width=100, height=200, transform="matrix(2,0,0,1,0,0)")
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["angle"], 0)
        self.assertEquals(p["size"], (200,200))

    def test_rect_sclae(self):
        p = parse_rect(width=100, height=200, transform="scale(2, -1)")
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], (200,200))

    def test_rect_void_transform(self):
        p = parse_rect(transform="")
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["angle"], 0)

    def test_rect_transform2polygon(self):
        p = parse_rect(transform="scale(10, 2) rotate(30)")
        self.assertTrue(isinstance(p, phn_output.Polygon))

    def test_rect_ry(self):
        p = parse_rect(ry="0.1")
        self.assertTrue(isinstance(p, phn_output.Polygon))

    def test_rect_ry_rx0(self):
        p = parse_rect(ry="0.1", rx="0")
        self.assertTrue(isinstance(p, phn_output.Box))

class testInkscapeEllipse(unittest.TestCase):
    def test_inkscape_ellipse_normal_ellipse(self):
        p = parse_inkscape_ellipse()
        self.assertTrue(isinstance(p, phn_output.Circle))

    def test_inkscape_ellipse_rotated_ellipse(self):
        p = parse_inkscape_ellipse(transform="rotate(30)")
        self.assertTrue('angle' in p)
        self.assertTrue(isinstance(p, phn_output.Circle))
        self.assertAlmostEquals(p['angle'], pi/6)
        self.assertEquals(p['radius'], 1)

    def test_inkscape_ellipse_scaled_ellipse(self):
        p = parse_inkscape_ellipse(transform="scale(1,2)")
        self.assertTrue(isinstance(p, phn_output.Polygon))

    def test_inkscape_ellipse_half_ellipse(self):
        attributes={"sodipodi:end":"1"}
        p = parse_inkscape_ellipse(**attributes)
        self.assertTrue(isinstance(p, phn_output.Polygon))

class testPath(unittest.TestCase):
    pass #TODO Pathが真円状の場合に, sodipodi:rxのような表記がなくても、Polygonでなく、Circleに変換できるように。
#    def test_path_perfect_circle(self):
#        p = parse_path(d="m -201.59999,10.8 a 28.799999,28.799999 0 1 1 -57.6,0 28.799999,28.799999 0 1 1 57.6,0 z")
#        self.assertTrue(isinstance(p, phn_output.Circle))

class testEllipse(unittest.TestCase):
    pass #FIXME テストケースの追加。


class testMatrix(unittest.TestCase):
    def test_matrix(self):
        p = parse_rect(width=100, height=200, transform="scale(2, -1)")
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], (200,200))

    def test_matrix_invalid(self):
        p = parse_rect(width=100, height=200, transform="scale(2, -1")
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], (100,200))

    def test_matrix_invalid2(self):
        p = parse_rect(width=100, height=200, transform="scale(2, -1, 3)")
        self.assertTrue(isinstance(p, phn_output.Box))
        self.assertEquals(p["size"], (100,200))

class testVector(unittest.TestCase):
    def test_vector_add(self):
        a = phn_output.Vector([1,2])
        b = phn_output.Vector([3,4])
        self.assertEquals(a+b, phn_output.Vector([4, 6]))

    def test_vector_pos(self):
        a = phn_output.Vector([1,2])
        self.assertEquals(+a, phn_output.Vector([1, 2]))

    def test_vector_neg(self):
        a = phn_output.Vector([1,2])
        self.assertEquals(-a, phn_output.Vector([-1, -2]))

    def test_vector_norm(self):
        a = phn_output.Vector([3,4])
        self.assertEquals(abs(a), 5)

class testGroup(unittest.TestCase):
    def test_group_rotates(self):
        elements = ("g", {"transform":"rotate(30)"}, ("rect", {"transform":"rotate(60)"}))
        p = parse_elements(elements)
        self.assertAlmostEquals(p[0]['angle'], pi/2)
        self.assertTrue(isinstance(p[0], phn_output.Box))

    def test_group_scales(self):
        elements = ("g", {"transform":"scale(1,-3)"}, ("rect", {"width":100, "height":100, "transform":"scale(10,2)"}))
        p = parse_elements(elements)
        self.assertEquals(p[0]['size'], phn_output.Vector([1000, 600]))

    def test_group_scales_triple(self):
        elements = ("g", {"transform":"scale(0.5,-3)"},
                        ("g", {"transform":"scale(1,-3)"},
                            ("rect", {"width":100, "height":100, "transform":"scale(10,2)"})))
        p = parse_elements(elements)
        self.assertEquals(p[0]['size'], phn_output.Vector([500, 1800]))

    def test_group_opacity(self):
        elements = ("g", {"style":"opacity:0.2"},
                        ("g", {"opacity":"0.3"},
                            ("rect", {"style":"fill-opacity:0.7;fill:#00FFFF"})))
        p = parse_elements(elements)
        self.assertAlmostEquals(p[0]['color'][3], 0.042)


class testTemp(unittest.TestCase):
    def test_style_fill_red(self):
        p = parse_rect(style='fill:#FF0000')
        self.assertEquals(p["color"], phn_output.Color([1, 0, 0, 1]))


##########################################
def suite():
    suite = unittest.TestSuite()

    DEBUG = False
    if DEBUG:
        suite.addTest(unittest.makeSuite(testTemp))
    else:
        suite.addTest(unittest.makeSuite(testStyle))
        suite.addTest(unittest.makeSuite(testRect))
        suite.addTest(unittest.makeSuite(testInkscapeEllipse))
        suite.addTest(unittest.makeSuite(testPath))
        suite.addTest(unittest.makeSuite(testEllipse))
        suite.addTest(unittest.makeSuite(testMatrix))
        suite.addTest(unittest.makeSuite(testVector))
        suite.addTest(unittest.makeSuite(testGroup))

    return suite

if __name__ == '__main__':
    unittest.TextTestRunner(verbosity=1).run(suite())

# vim: expandtab shiftwidth=4 tabstop=8 softtabstop=4 encoding=utf-8 textwidth=99
