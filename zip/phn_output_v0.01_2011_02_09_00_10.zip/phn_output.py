#!/usr/bin/env python
# coding: utf-8

"""
phn_output.py (Inkscape extension)

Copyright (C) 2011 Tatt61880 (tatt61880@gmail.com, @tatt61880)
jast Change: 2011/02/04 10:23:02.

"""
#TODO 自己交差しているパスや複合パスへの対応
#TODO fill-ruleがnonzero で自己交差している場合に警告を出力
#TODO Transformクラスを作成。Transform("Scale(1,1)")という具合にインスタンス作成。
#TODO Inkscapeに同梱されたライブラリからの独立(依存をなくす)
#TODO __init__(self, *rest, **key) のようなコンストラクタ
#TODO 警告を重複して表示しない。どの警告が何度,どの箇所で出たかを表示。
#TODO use要素に対応
#TODO Scene.Cameraに対応
#TODO リファクタリング!

VERSION = '0.01'

# ベジエ曲線を線分に分割する際の精度。1つのベジエ曲線あたりの点数。
NODES = 16

import sys, re
from math import *
from random import random
import cubicsuperpath
from xml.etree.ElementTree import ElementTree
#from xml.etree.ElementTree import dump

xmlns = '{http://www.w3.org/2000/svg}'
sodipodi = '{http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd}'

ORIGINAL_DATA_OUTPUT = False

# MINIMUM_MODEをFalseにすると、デフォルトのパラメータも出力する。例えば density = 2.0など。
# Algodoo用のパラメータを多数出力してしまうため、MINIMUM_MODE=Trueにしておくのがオススメ。
# FIXME MINIMUM_MODEは全くテストしていません。
MINIMUM_MODE = True


# ========================================
# クラス
# ========================================
class NumTuple(tuple): #{{{
    def __repr__(self):
        ret = '['
        for item in self:
            ret += "%g" % item + ', '
        return ret[:-2] + ']'

#}}}
class Color(NumTuple): #{{{
    def __init__(self, data):
        if len(self) != 4:
            raise ValueError('Color must be 4 element array ([r,g,b,a]).')
#}}}
class Vector(NumTuple):#{{{
    def en_matrix(self, m):
        '''transformのmatrix操作'''
        return Vector([m[0]*self[0]+m[2]*self[1]+m[4],
                       m[1]*self[0]+m[3]*self[1]+m[5]])

    def __pos__(self):
        return self
    def __neg__(self):
        return Vector([-a for a in self])

    def __add__(self, other):
        if len(self) == len(other):
            return Vector([a+b for a, b in zip(self, other)])
        else:
            raise ValueError('Vector dimension error.')
    def __sub__(self, other):
        return self.__add__(-other)
    def __mul__(self, other):
        if isinstance(other, Vector):
            if len(self) == len(other):
                return sum([a*b for a, b in zip(self, other)])
            else:
                raise ValueError('Vector dimension error.')
        else:
            try:
                return Vector([other*a for a in self])
            except:
                raise ValueError('Strange value.')

    def __abs__(self):
        return sqrt(sum([a*a for a in self]))
#}}}

class _PhunObject(dict):#{{{
    _default = {
            'color':[float(random()), float(random()), float(random()), 1], #FIXME
            #'entityID':1, #FIXME
            #'zDepth':1.0, #FIXME
            }
    def __str__(self):
        temp = "Scene.add%s {\n" % self.__class__.__name__
        for key, value in self.items():
            if isinstance(value, str):
                if(value != "+inf"):
                    value = '''"%s"''' % value
            elif isinstance(value, bool):
                if value:
                    value = 'true'
                else:
                    value = 'false'
            elif isinstance(value, float):
                value = "%g" % value
            temp += "    %s := %s;\n" % (key, value)
        temp += '};'
        return temp

    def __repr__(self):
        return "<%s at %x>" % (self.__class__.__name__, id(self))

    def __init__(self, attrib):
        if not MINIMUM_MODE:
            self.update(self.default)
        self.update(attrib)
#}}}

class _PhunGeometry(_PhunObject): #{{{
    default = _PhunObject._default.copy()
    default.update({
            'airFrictionMult':1.0,
            'angle':0.0,
            'attraction':0.0,
            'collideSet':1,
            'collideWater':True,
            'controllerAcc':11.0,
            'controllerInvertX':False,
            'controllerInvertY':False,
            'controllerReverseXY':False,
            'density':2.0,
            'drawBorder':True,
            'friction':0.5,
            #'geomID':1, #FIXME
            'heteroCollide':False,
            'immortal':False,
            'inertiaMultiplier':1.0,
            'killer':False,
            'materialVelocity':0.0,
            'onCollide':'(e)=>{}',
            'onHitByLaser':'(e)=>{}',
            'opaqueBorders':True,
            #'pos':[0.0, 0.0], #FIXME
            'reflectiveness':1.0,
            'refractiveIndex':1.5,
            'restitution':0.5,
            'showForceArrows':False,
            'showVelocity':False,
            'textColor':[1.0, 1.0, 1.0, 1.0],
            'textConstrained':True,
            'textFont':'Verdana', #FIXME 適切なフォントは?
            'textFontSize':32.0,
            'textScale':0.5,
            'texture':'',
            'textureMatrix':[1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
            })
#}}}
class Polygon(_PhunGeometry): #{{{1
    default = _PhunGeometry._default.copy()
    default.update({
            })
#}}}1
class Box(_PhunGeometry): #{{{
    default = _PhunGeometry._default.copy()
    default.update({
            'size':[1,0, 1,0],
            'text':'',
            'ruler':False,
            })
#}}}
class Circle(_PhunGeometry): #{{{
    default = _PhunGeometry._default.copy()
    default.update({
            'drawCake':True,
            'radius':1.0,
            })
#}}}
class Plane(_PhunGeometry): #{{{1
    default = _PhunGeometry._default.copy()
    default.update({
            })
#}}}1

class _PhunAttachment(_PhunObject):#{{{
    default = _PhunObject._default.copy()
    default.update({
            'size':0.1,
            #'opaqueBorders':True,
            })
#}}}
class Spring(_PhunAttachment):#{{{
    default = _PhunAttachment._default.copy()
    default.update({
            'geom0':0,
            'geom0pos':[0.0, 0.0],
            'geom1':0,
            'geom1pos':[0.0, 0.0],
            'dampingFactor':0.1,
            'legacyMode':2,
            'length':0.0,
            'constant':0.1,
            })
#}}}
class Fixjoint(_PhunAttachment):#{{{
    default = _PhunAttachment._default.copy()
    default.update({
            'geom0':-1,
            'world0pos':[0, 0],
            'geom1':0,
            'geom1ps':[0, 0],
            })
#}}}
class Hinge(_PhunAttachment):#{{{
    default = _PhunAttachment._default.copy()
    default.update({
            'geom0':-1,
            'world0pos':[0, 0],
            'geom1':-1,
            'world1pos':[0, 0],
            'ccw':False,
            'motorTorque':100.0,
            'impulseLimit':"+inf",
            'autoBrake':False,
            'motor':False,
            'motorSpeed':1.5707964,
            'distanceLimit':"+inf",
            })
#}}}
class Pen(_PhunAttachment): #{{{
    default = _PhunAttachment._default.copy()
    default.update({
            'fadeTime':1.5,
            'geom':1,
            'relPoint':Vector([0, 0]),
            'rotation':0
            })
#}}}
class LaserPen(_PhunAttachment): #{{{
    default = _PhunAttachment._default.copy()
    default.update({
            'geom':0,
            'cutter':False,
            'collideSet':127,
            'collideWater':True,
            'onLaserHit':"(e)=>{}",
            'pos':Vector([0, 0]),
            'velocity':"+inf",
            'fadeDist':25.0,
            'maxRays':1000,
            'showLaserBodyAttrib':True,
            'rotation':0.0
            })
#}}}

# ========================================
def get_style(e): #{{{
    ''' fillやstrokeなどの属性をまとめる。'''
    #TODO 必要十分か確認
    ret = {}
    for attribute in ("fill", "fill-opacity", "stroke", "opacity"):
        if e.get(attribute):
            ret.update({attribute:e.get(attribute)})
    style = e.get("style")
    if style:
        style = re.sub(r'\s*', '', style)
        styles = {}
        for property in style.split(';'):
            if not property: continue
            try:
                property_name, value = property.split(':')
            except ValueError: #style="a"など変則的な(不適切な)style
                sys.stderr.write("### Warning: ValueError for style (%s).\n" % style)
                styles = {}
                break
            styles.update({property_name:value})
        ret.update(styles)
    return ret.copy()
#}}}
def update_style(e, inherited_style): #{{{
    current_style = get_style(e)
    if inherited_style:
        ret = inherited_style.copy()
        ret.update(current_style)
        if 'opacity' in inherited_style and 'opacity' in current_style:
            ret.update({'opacity':float(inherited_style['opacity'])*float(current_style['opacity'])})
    else:
        ret = current_style
    return ret.copy()
#}}}

def combine_matrices(m1, m2): #{{{
    return (
        m1[0]*m2[0] + m1[2]*m2[1],
        m1[1]*m2[0] + m1[3]*m2[1],
        m1[0]*m2[2] + m1[2]*m2[3],
        m1[1]*m2[2] + m1[3]*m2[3],
        m1[0]*m2[4] + m1[2]*m2[5] + m1[4],
        m1[1]*m2[4] + m1[3]*m2[5] + m1[5],
        )
#}}}

def transform_to_matrix(transform): #{{{
    '''
    単一の transformを、matrixに変換
    transform: matrix | translate | scale | rotate | skewX | skewY
    '''
    label = re.sub(r'^\s*(\w+).*', r'\1', transform)
    in_paren = re.sub(r'^.*?\(\s*(.*?)\s*\).*', r'\1', transform) #最初の括弧内
    try:
        # パラメータのリストを得て、各要素(文字列型)を数値(float型)に変換
        params = [float(param) for param in re.split(r',', re.sub(r'\s+,?\s*|,\s*', r',', in_paren))]
    except ValueError:
        sys.stderr.write("### Warning: ValueError for transform (%s).\n" % transform)
        return (1,0,0,1,0,0)

    if(label == 'matrix'):
        if len(params)==6: matrix = params
    elif(label == 'translate'):
        if len(params)==1: params.append(0)
        if len(params)==2: matrix = (1, 0, 0, 1, params[0], params[1])
    elif(label == 'scale'):
        if len(params)==1: params.append(params[0])
        if len(params)==2: matrix = (params[0], 0, 0, params[1], 0, 0)
    elif(label == 'rotate'):
        if len(params)==1:
            theta = params[0]*pi/180.
            matrix = (cos(theta), sin(theta), -sin(theta), cos(theta), 0, 0)
        elif len(params)==3:
            # rotate(<rotate-angle> <cx> <cy>)は下記と同等
            # translate(<cx>, <cy>) rotate(<rotate-angle>) translate(-<cx>, -<cy>)
            transforms = "translate(%s %s) rotate(%s) translate(%s %s)" % (
                    params[1], params[2], params[0], -params[1], -params[2])
            matrix = transforms_to_matrix(transforms)
    elif(label == 'skewX'):
        if len(params)==1:
            theta = params[0]*pi/180.
            matrix = (1, 0, tan(theta), 1, 0, 0)
    elif(label == 'skewY'):
        if len(params)==1:
            theta = params[0]*pi/180.
            matrix = (1, tan(theta), 0, 1, 0, 0)
    else:
        sys.stderr.write("### Warning: Unknown label for transform ('%s').\n" % label)
        matrix = (1,0,0,1,0,0)

    try:
        return matrix
    except:
        sys.stderr.write("### Warning: %s%s cannot be handled.\n" % (label, tuple(params)))
        return (1,0,0,1,0,0)
#}}}
def transforms_to_matrix(transforms): #{{{
    '''
    引数がどのタイプのtransform(s)でも matrixに変換する。
    "rotate(30) scale(1,2)" のように複数のtransformを合わせた文字列も扱う。
    '''
    matrix = (1,0,0,1,0,0)
    m = re.findall(r'\w+\(.*?\)', str(transforms))
    if m:
        try:
            for transform in m:
                matrix = combine_matrices(matrix, transform_to_matrix(transform))
        except:
            sys.stderr.write("### Warning: ValueError for transform (%s).\n" % transforms)
    else: # transforms is None or "", etc.
        pass
    return matrix
#}}}

def string_to_rgb(color_description): #{{{
    def color_value(value):
        m=re.search(r'^(.*)%\s*$', value)
        if m: # "100%" や " 100 % ", "0.5%"など。
            ret = float(m.group(1))/100.
        else:
            try:
                ret = float(value)/255.
            except:
                ret = 0
                sys.stderr.write("### Warning: ValueError for rgb color value (%s).\n" % value)
        return ret

    colorkeywords = { # ColorKeywords {{{
        "aliceblue"           :"#F0F8FF",
        "antiquewhite"        :"#FAEBD7",
        "aqua"                :"#00FFFF",
        "aquamarine"          :"#7FFFD4",
        "azure"               :"#F0FFFF",
        "beige"               :"#F5F5DC",
        "bisque"              :"#FFE4C4",
        "black"               :"#000000",
        "blanchedalmond"      :"#FFEBCD",
        "blue"                :"#0000FF",
        "blueviolet"          :"#8A2BE2",
        "brown"               :"#A52A2A",
        "burlywood"           :"#DEB887",
        "cadetblue"           :"#5F9EA0",
        "chartreuse"          :"#7FFF00",
        "chocolate"           :"#D2691E",
        "coral"               :"#FF7F50",
        "cornflowerblue"      :"#6495ED",
        "cornsilk"            :"#FFF8DC",
        "crimson"             :"#DC143C",
        "cyan"                :"#00FFFF",
        "darkblue"            :"#00008B",
        "darkcyan"            :"#008B8B",
        "darkgoldenrod"       :"#B8860B",
        "darkgray"            :"#A9A9A9",
        "darkgreen"           :"#006400",
        "darkgrey"            :"#A9A9A9",
        "darkkhaki"           :"#BDB76B",
        "darkmagenta"         :"#8B008B",
        "darkolivegreen"      :"#556B2F",
        "darkorange"          :"#FF8C00",
        "darkorchid"          :"#9932CC",
        "darkred"             :"#8B0000",
        "darksalmon"          :"#E9967A",
        "darkseagreen"        :"#8FBC8F",
        "darkslateblue"       :"#483D8B",
        "darkslategray"       :"#2F4F4F",
        "darkslategrey"       :"#2F4F4F",
        "darkturquoise"       :"#00CED1",
        "darkviolet"          :"#9400D3",
        "deeppink"            :"#FF1493",
        "deepskyblue"         :"#00BFFF",
        "dimgray"             :"#696969",
        "dimgrey"             :"#696969",
        "dodgerblue"          :"#1E90FF",
        "firebrick"           :"#B22222",
        "floralwhite"         :"#FFFAF0",
        "forestgreen"         :"#228B22",
        "fuchsia"             :"#FF00FF",
        "gainsboro"           :"#DCDCDC",
        "ghostwhite"          :"#F8F8FF",
        "gold"                :"#FFD700",
        "goldenrod"           :"#DAA520",
        "gray"                :"#808080",
        "grey"                :"#808080",
        "green"               :"#008000",
        "greenyellow"         :"#ADFF2F",
        "honeydew"            :"#F0FFF0",
        "hotpink"             :"#FF69B4",
        "indianred"           :"#CD5C5C",
        "indigo"              :"#4B0082",
        "ivory"               :"#FFFFF0",
        "khaki"               :"#F0E68C",
        "lavender"            :"#E6E6FA",
        "lavenderblush"       :"#FFF0F5",
        "lawngreen"           :"#7CFC00",
        "lemonchiffon"        :"#FFFACD",
        "lightblue"           :"#ADD8E6",
        "lightcoral"          :"#F08080",
        "lightcyan"           :"#E0FFFF",
        "lightgoldenrodyellow":"#FAFAD2",
        "lightgray"           :"#D3D3D3",
        "lightgreen"          :"#90EE90",
        "lightgrey"           :"#D3D3D3",
        "lightpink"           :"#FFB6C1",
        "lightsalmon"         :"#FFA07A",
        "lightseagreen"       :"#20B2AA",
        "lightskyblue"        :"#87CEFA",
        "lightslategray"      :"#778899",
        "lightslategrey"      :"#778899",
        "lightsteelblue"      :"#B0C4DE",
        "lightyellow"         :"#FFFFE0",
        "lime"                :"#00FF00",
        "limegreen"           :"#32CD32",
        "linen"               :"#FAF0E6",
        "magenta"             :"#FF00FF",
        "maroon"              :"#800000",
        "mediumaquamarine"    :"#66CDAA",
        "mediumblue"          :"#0000CD",
        "mediumorchid"        :"#BA55D3",
        "mediumpurple"        :"#9370DB",
        "mediumseagreen"      :"#3CB371",
        "mediumslateblue"     :"#7B68EE",
        "mediumspringgreen"   :"#00FA9A",
        "mediumturquoise"     :"#48D1CC",
        "mediumvioletred"     :"#C71585",
        "midnightblue"        :"#191970",
        "mintcream"           :"#F5FFFA",
        "mistyrose"           :"#FFE4E1",
        "moccasin"            :"#FFE4B5",
        "navajowhite"         :"#FFDEAD",
        "navy"                :"#000080",
        "oldlace"             :"#FDF5E6",
        "olive"               :"#808000",
        "olivedrab"           :"#6B8E23",
        "orange"              :"#FFA500",
        "orangered"           :"#FF4500",
        "orchid"              :"#DA70D6",
        "palegoldenrod"       :"#EEE8AA",
        "palegreen"           :"#98FB98",
        "paleturquoise"       :"#AFEEEE",
        "palevioletred"       :"#DB7093",
        "papayawhip"          :"#FFEFD5",
        "peachpuff"           :"#FFDAB9",
        "peru"                :"#CD853F",
        "pink"                :"#FFC0CB",
        "plum"                :"#DDA0DD",
        "powderblue"          :"#B0E0E6",
        "purple"              :"#800080",
        "red"                 :"#FF0000",
        "rosybrown"           :"#BC8F8F",
        "royalblue"           :"#4169E1",
        "saddlebrown"         :"#8B4513",
        "salmon"              :"#FA8072",
        "sandybrown"          :"#F4A460",
        "seagreen"            :"#2E8B57",
        "seashell"            :"#FFF5EE",
        "sienna"              :"#A0522D",
        "silver"              :"#C0C0C0",
        "skyblue"             :"#87CEEB",
        "slateblue"           :"#6A5ACD",
        "slategray"           :"#708090",
        "slategrey"           :"#708090",
        "snow"                :"#FFFAFA",
        "springgreen"         :"#00FF7F",
        "steelblue"           :"#4682B4",
        "tan"                 :"#D2B48C",
        "teal"                :"#008080",
        "thistle"             :"#D8BFD8",
        "tomato"              :"#FF6347",
        "turquoise"           :"#40E0D0",
        "violet"              :"#EE82EE",
        "wheat"               :"#F5DEB3",
        "white"               :"#FFFFFF",
        "whitesmoke"          :"#F5F5F5",
        "yellow"              :"#FFFF00",
        "yellowgreen"         :"#9ACD32",
    }
    # }}}

    m=re.search(r'rgb\(([^,]*),([^,]*),([^,]*)\)', color_description)
    if m:
        """rgb(255,255,255)形式"""
        r = color_value(m.group(1))
        g = color_value(m.group(2))
        b = color_value(m.group(3))
    else:
        if re.search(r'^#[0-9a-fA-F]{6}$', color_description):
            """#FFFFFF形式"""
            pass
        elif re.search(r'^#[0-9a-fA-F]{3}$', color_description):
            """#FFF形式"""
            temp = ""
            for s in color_description:
                temp += s + s
            color_description = temp[1:]
        else:
            """文字列による色指定(例えばredなど)の場合"""
            try:
                color_description = colorkeywords[color_description]
            except:
                sys.stderr.write(
                    "### Warning (%s):Color name \"%s\" cannot be handled.\n"
                    % (sys.argv[0], color_description)
                             )
                color_description = "#000000"

        r = int(color_description[1:3], 16) / 255.
        g = int(color_description[3:5], 16) / 255.
        b = int(color_description[5:7], 16) / 255.
    return (r,g,b)
#}}}
def get_color(styles): #{{{
    if not styles:
        r, g, b, o, drawBorder = 0, 0, 0, 1, True
    else:
        drawBorder = False
        if 'fill' in styles:
            fill = styles['fill']
            if fill=='none':
                drawBorder = True
                if 'stroke' in styles:
                    if styles['stroke'] == 'none':
                        stroke = '#000000'
                        drawBorder = False
                    else:
                        stroke = styles['stroke']
                else:
                    stroke = '#000000'
                r, g, b = string_to_rgb(stroke)
                o = 0
            else:
                r, g, b = string_to_rgb(fill)
                if 'fill-opacity' in styles:
                    fill_opacity = styles['fill-opacity']
                else:
                    fill_opacity = '1'
                o = float(fill_opacity)
        else:
            r, g, b, o = 0, 0, 0, 1

        if 'opacity' in styles:
            o *= float(styles['opacity'])

    return Color([r, g, b, o]), drawBorder
#}}}

# ========================================
def bezier_to_path(p1, p2, p3, p4, nodes = NODES): #{{{
    '''
    ベジエ曲線上の点を返す。
    @params p1～p4: 制御点の座標(Vectorクラス)
    @params nodes(int型): 値を大きくすると点の数が増えて精度が増す。
    '''
    r = []
    for i in range(0, nodes+1):
        t = float(i) / nodes
        temp  = p1 * ((1-t)**3)
        temp += p2 * (3 * t * (1-t)**2)
        temp += p3 * (3 * t**2 * (1-t))
        temp += p4 * (t**3)
        r.append(Vector(temp))
    return tuple(r)
#}}}

# TODO text要素に対応
def parse_text(e, matrix, style): # {{{
    attributes = {}
#    attributes['color'] = color
#    attributes['drawBorder'] = drawBorder

#    #より適切な位置に, 適切な大きさで。ネストに注意
#    x = float(e.get("x", 0))
#    y = float(e.get("y", 0))
#    attributes["pos"] = Vector([x,y])
#    attributes["collideSet"] = 0
#    attributes["collideWater"] = False

    #return Box(attributes)
    return None
# }}}
def parse_path(e, m, style): #{{{
    # 真円の場合はCircleオブジェクトをreturn {{{
    type = e.get(sodipodi + 'type')
    if(type and type == 'arc'):
        rx = e.get(sodipodi + 'rx')
        ry = e.get(sodipodi + 'ry')
        start = e.get(sodipodi + 'start')
        end = e.get(sodipodi + 'end')
        if(rx == ry and not start and not end):
            if (abs(m[0])==abs(m[3]) and abs(m[1])==abs(m[2])):
                # 真円であることが確定
                cx = e.get(sodipodi + 'cx', 0)
                cy = e.get(sodipodi + 'cy', 0)
                e.set('cx', cx)
                e.set('cy', cy)
                e.set('r', rx)
                return parse_circle(e, m, style)
    #}}}

    attributes = {}
    color, drawBorder = get_color(style)
    attributes['color'] = color
    attributes['drawBorder'] = drawBorder

    d = cubicsuperpath.formatPath(cubicsuperpath.parsePath(e.get('d')))
    #sys.stderr.write("// d = %s\n" % d)
    d__ = [d_.split("C") for d_ in d[1:].split("M")]
    #sys.stderr.write("// d__ = %s\n" % d__)

    surfaces = []
    for cubics in d__:
        flag = True
        vecs = []
        for cubic in cubics:
            if flag:
                flag = False
                current_pos = Vector([float(i) for i in cubic.split()])
                continue
            temp = [float(i) for i in cubic.split()]
            vecs.extend(bezier_to_path(current_pos, Vector(temp[0:2]), Vector(temp[2:4]), Vector(temp[4:6])))
            current_pos = vecs[-1]
        # FIXME 自己交差のパスや複合パスに非対応。図形は作成されるけれど、パスの順序が正しくない。(カッターで切断すると違いがわかる。)
        vecs = [points.en_matrix(m) for points in vecs]
        # 同じ点が連続しないように間引く
        for i in range(len(vecs)-2, -1, -1):
            if (vecs[i] == vecs[i+1]):
                del vecs[i]
        surfaces.append(vecs)

    if(len(surfaces) != 1):
        index = 0;
        min_x_dict = {}
        # TODO 最小の点を返す関数を作成・利用
        for vecs in surfaces:
            min_x = vecs[0][0]
            for vec in vecs:
                if vec[0] < min_x:
                    min_x = vec[0]
            min_x_dict.update({index:min_x})
            index+=1
        sorted_min_x = sorted(min_x_dict.items(), key=lambda x:x[1])
        sorted_min_x_index = [i[0] for i in sorted_min_x]
        surfaces = [surfaces[i] for i in sorted_min_x_index]

    attributes.update({'surfaces':surfaces})
    return Polygon(attributes)
#}}}
def parse_rect(e, m, style): #{{{
    attributes = {}
    color, drawBorder = get_color(style)
    attributes['color'] = color
    attributes['drawBorder'] = drawBorder

    x = float(e.get('x', 0))
    y = float(e.get('y', 0))
    width  = float(e.get('width',  0))
    height = float(e.get('height', 0))

    try: rx = float(e.get('rx'))
    except: rx = None
    try: ry = float(e.get('ry'))
    except: ry = None
    if ((rx and ry!=0) or (ry and rx!=0)):
        # 角が丸いrect → パスとして扱う
        if not rx: rx = ry
        if not ry: ry = rx
        width2 = width -2*rx
        height2 = height -2*ry
        d  = "m %lf,%lf " % ((x+rx), y);
        d += "l %lf,0 " %  width2;
        d += "a %lf,%lf 0, 0,1 %lf,%lf"  % (rx,ry,  rx, ry);
        d += "l 0,%lf " %  height2;
        d += "a %lf,%lf 0, 0,1 %lf,%lf"  % (rx,ry, -rx, ry);
        d += "l %lf,0 " % -width2;
        d += "a %lf,%lf 0, 0,1 %lf,%lf"  % (rx,ry, -rx,-ry);
        d += "l 0,%lf " % -height2;
        d += "a %lf,%lf 0, 0,1 %lf,%lf"  % (rx,ry,  rx,-ry);
        e.set('d', d)
        return parse_path(e, m, style)

    if (m[0]*m[2]!=-m[1]*m[3]):
        # transformによりrect(直方体)でなくなっている → パスとして扱う
        p0x, p0y = x, y
        p1x, p1y = x+width, y
        p2x, p2y = x+width, y+height
        p3x, p3y = x, y+height
        d = "M %lf,%lf %lf,%lf %lf,%lf %lf,%lf z" % (p0x, p0y, p1x, p1y, p2x, p2y, p3x, p3y)
        e.set('d', d)
        return parse_path(e, m, style)

    pos = Vector([x+width/2., y+height/2.]).en_matrix(m)
    size = Vector([abs(Vector([x+width, y]).en_matrix(m) - Vector([x,y]).en_matrix(m)),
                   abs(Vector([x,y+height]).en_matrix(m) - Vector([x,y]).en_matrix(m)) ])
    angle = atan2(m[1], m[0])

    attributes.update({'pos':pos})
    attributes.update({'size':size})
    attributes.update({'angle':angle})
    return Box(attributes)
#}}}
def parse_ellipse(e, m, style):#{{{
    attributes = {}
    color, drawBorder = get_color(style)
    attributes['color'] = color
    attributes['drawBorder'] = drawBorder

    cx = float(e.get('cx', 0))
    cy = float(e.get('cy', 0))
    rx = float(e.get('rx'))
    ry = float(e.get('ry'))

    d  = "m %lf,%lf" % (cx,cy-ry);
    d += "a %lf,%lf 0, 0,1 %lf,%lf"  % (rx,ry,  rx, ry);
    d += "a %lf,%lf 0, 0,1 %lf,%lf"  % (rx,ry, -rx, ry);
    d += "a %lf,%lf 0, 0,1 %lf,%lf"  % (rx,ry, -rx,-ry);
    d += "a %lf,%lf 0, 0,1 %lf,%lf"  % (rx,ry,  rx,-ry);
    e.set('d', d)
    return parse_path(e, m, style)
#}}}
def parse_circle(e, m, style): #{{{
    attributes = {}
    color, drawBorder = get_color(style)
    attributes['color'] = color
    attributes['drawBorder'] = drawBorder
    attributes['drawCake'] = False

    cx = float(e.get('cx', 0))
    cy = float(e.get('cy', 0))
    r  = float(e.get('r'))

    if (abs(m[0])!=abs(m[3]) or abs(m[1])!=abs(m[2])):
        # transformにより円でなくなっている → ellipseとして扱う
        e.set('rx', r)
        e.set('ry', r)
        return parse_ellipse(e, m, style)

    pos = Vector([cx, cy]).en_matrix(m)
    radius = r * abs(sqrt(m[0]**2+m[1]**2))
    attributes.update({'pos':pos})
    attributes.update({'radius':radius})
    angle = atan2(m[1], m[0])
    attributes.update({'angle':angle})

    if("filter" in style):
        # filterの属性を持った真円はトレーサーに変換
        attributes = {
                'pos':attributes['pos'],
                'size':attributes['radius']*2,
                'color':attributes['color'],
                }
        #for attribute in ('drawCake', 'drawBorder', 'radius' ): del attributes[attribute]
        return Pen(attributes)

#    if("marker-mid" in style):
#        # marker-midを持った真円はヒンジに変換
#        attributes = {
#                'geom0':0, # FIXME
#                'geom0pos':attributes['pos'],
#                'geom1':0, # FIXME
#                'geom1pos':attributes['pos'],
#                'size':attributes['radius']*2,
#                }
#        return Hinge(attributes)

    return Circle(attributes)
#}}}

def parse_line(e, m, style): #{{{
    attributes = {}
    color, drawBorder = get_color(style) #FIXME

    x1 = float(e.get('x1', 0))
    y1 = float(e.get('y1', 0))
    x2 = float(e.get('x2', 0))
    y2 = float(e.get('y2', 0))
    pos1 = Vector([x1,y1]).en_matrix(m)
    pos2 = Vector([x2,y2]).en_matrix(m)
    attributes['color'] = color
    attributes['geom0'] = 0 #FIXME
    attributes['geom0pos'] = pos1
    attributes['geom1'] = 0 #FIXME
    attributes['geom1pos'] = pos2

    return Spring(attributes)
#}}}
def parse_polyline(e, m, style): #{{{
    color, drawBorder = get_color(style) #FIXME

    points = e.get('points', 0)
    #m=re.search(r'([^, ]*)[, ]([^, ]*)[, ]*$', points)
    match=re.search(r'([^, ]*)[, ]*([^, ]*)[, ]*([^, ]*)[, ]*([^, ]*)[, ]*$', points)

    x0, y0 = float(match.group(1)), float(match.group(2))
    x1, y1 = float(match.group(3)), float(match.group(4))
    pos = Vector([x0,y0]).en_matrix(m)
    pos_end = Vector([x1,y1]).en_matrix(m)
    direction = (pos_end-pos)

    attributes = {
            'color':color,
            'pos':pos,
            'angle':atan2(direction[1], direction[0])
            }
    return Plane(attributes)
#}}}
# ========================================
def parse_svg(element, inherited_matrix, inherited_style, phun): #{{{
    for e in list(element):
        current_style = update_style(e, inherited_style)
        current_matrix = combine_matrices(inherited_matrix, transforms_to_matrix(e.get('transform')))
        if e.tag == (xmlns+'g'):
            parse_svg(e, current_matrix, current_style, phun)
        elif e.tag == (xmlns+'path'):
            phun.append(parse_path(e, current_matrix, current_style))
        elif e.tag == (xmlns+'rect'):
            phun.append(parse_rect(e, current_matrix, current_style))
        elif e.tag == (xmlns+'circle'):
            phun.append(parse_circle(e, current_matrix, current_style))
        elif e.tag == (xmlns+'ellipse'):
            phun.append(parse_ellipse(e, current_matrix, current_style))
        elif e.tag == (xmlns+'text'):
            #TODO text要素に対応
            #sys.stderr.write("### Warning (%s): This script doesn't handle "
            #                 "'text' element, yet.###\n" % sys.argv[0])
            phun.append(parse_text(e, current_matrix, style_info))
        elif e.tag == (xmlns+'line'):
            phun.append(parse_line(e, current_matrix, style_info))
        elif e.tag == (xmlns+'polyline'):
            phun.append(parse_polyline(e, current_matrix, style_info))
#}}}
# ========================================

if __name__ == '__main__':
    f = file(sys.argv[1], 'r')
    et = ElementTree(file=f)
    f.close()
    # 90で割ると、Inkscapeの1インチをPhunの1メートルに変換できる。
    scaleX, scaleY = 1/90.0, -1/90.0
    #scaleX, scaleY = 1,1
    transform = "scale(%lf,%lf)" % (scaleX, scaleY)
    style_info = {}
    phun = []
    parse_svg(et.getroot(), transforms_to_matrix(transform), style_info, phun)

    for (i, o) in enumerate(phun):
        if (isinstance(o, _PhunGeometry)):
            o.update({'geomID':i+1})

    #変換後のデータを出力
    print "// Phun scene created by %s v%s" % (sys.argv[0], VERSION)
    for o in phun:
        if (isinstance(o, _PhunGeometry)): # 図形を出力
            print str(o)

    for o in phun:
        if (isinstance(o, _PhunAttachment)): # アタッチメントを出力
            print str(o)

    if ORIGINAL_DATA_OUTPUT:
        # 元データを出力
        print '/** Original SVG data'
        f = file(sys.argv[1], 'r')
        for line in f:
            print line,
        f.close()
        print '*/'

# vim: expandtab shiftwidth=4 tabstop=8 softtabstop=4 encoding=utf-8 textwidth=99
